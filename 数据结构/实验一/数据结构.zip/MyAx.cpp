#include <iostream.h>


//float Ax1(float A[],int n, float x);
//float Ax2(float A[],int n, float x);
//float Ax3(float A[],int n, float x);

void main( )
{  int n1;
  float x1,B[100];


cout<<"����ʽA(x)�еĲ�����:(1) n, (2) x,  (3) a1~an"<<endl;
cout<<"�����룺 n=";
cin>>n1;
cout<<endl;
cout<<"�����룺 x=";
cin>>x1;
cout<<endl;

cout<<"������ϵ��an~a0��"<<endl;
for (int i=n1; i>=0; i--)
	{
	 cout<<"   a["<<i<<"]=";
     cin>>B[i];
     //cout<<endl;
	}

 // cout<<"  A1(x)="<<Ax1(B,n1,x1)<<endl; 
 // cout<<"  A2(x)="<<Ax2(B,n1,x1)<<endl; 
 // cout<<"  A3(x)="<<Ax3(B,n1,x1)<<endl; 

}

//float Ax1(float A[],int n, float x)
//{   

//}
//float Ax2(float A[],int n, float x)
//{   

//}
//float Ax3(float A[],int n, float x)
//{   

//}

