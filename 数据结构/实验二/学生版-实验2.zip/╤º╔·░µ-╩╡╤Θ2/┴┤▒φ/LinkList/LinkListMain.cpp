//LinkListMain.cpp
#include <iostream.h>
#include "LinkList.cpp"
void main( )
{

 LinkList <int> a;
//Insert(?)
//Length()
//Get(?)
//Locate(?)
//Delete(?)  Length()
//PrintList()

//int r[ ]={xxxxx};
//LinkList <int> b(r,?)
//PrintList()
 //Length()
 //Insert(?)
 //PrintList()
 //Length()
//b.Delete(?)
 //Length()
 //PrintList()
}