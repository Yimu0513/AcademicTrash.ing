//SeQListMain.cpp
#include <iostream.h>
#include "SeqList.cpp"

void main( )
{
  
  SeqList<int>a;
  //Insert(?)
  //Length()
  //Get(?)
  //Locate(？)
  //Length()
  //Delete(?)
  //Length()
//PrintList()

  //int r[]={xxxx};
  //SeqList <int> b(r,?);
  //PrintList()
  //Length()
  //Insert(xx)
  //PrintList()
  //Length()
 //Delete(?)
//PrintList()
  
  //===========================================================
  int rr[]={11,2,33,104,15};
  SeqList <int> c(rr,5); 
  // 学生完成以下功能,利用实例线性表对象c提供的成员函数功能，
  //(1) 在第三数33前插入 -10；(2) 输出线性表的最大值与最小值

  //===========================================================


}