//SeQListMain.cpp
#include <iostream.h>
#include "SeqList.cpp"

void main( )
{
  
  SeqList<int>a;
  //Insert(?)
  //Length()
  //Get(?)
  //Locate(？)
  //Length()
  //Delete(?)
  //Length()
//PrintList()



  //===========================================================
  int rr[]={11,2,51,33,104,15};
  SeqList <int> c(rr,6); 
  // 学生完成以下功能,利用实例线性表对象c提供的成员函数功能，
  //(1) 在104前插入 -10，并打印线性表长度；
  //(2) 输出线性表的最大值与最小值

  //===========================================================


}