## misc

首先翻看流量爆发现很多的TLS协议和一个key

![image-20240331210732398](misc.assets/image-20240331210732398.png)

解密流量包

![image-20240331210832608](misc.assets/image-20240331210832608.png)

猜测是冰蝎

![image-20240331210856690](misc.assets/image-20240331210856690.png)

3132找到🐎

![image-20240331211100867](misc.assets/image-20240331211100867.png)

冰蝎4.0

```
<?php
function decrypt($data){
    $key='e45e329feb5d925b';
    $bs='base64_'.'decode';
    $after=$bs($data."");
    for($i=0;$i<strlen($after);$i++){
        $after[$i]=$after[$i]^$key[$i+1&15];
    }
    echo $after;
    return $after;
}
$data='TxcWR1NNExZAD0ZaAWMIPAZjH1BFBFtHThcJSlUXWEduWB1baAoSKThiMk5qBwYTVWJQXWoLFhI4BlRyEEg=';
decrypt($data);
?>

```

![image-20240331211334274](misc.assets/image-20240331211334274.png)

提示keepgoingjpg，猜测隐写找到key

3152找到密码

![image-20240331211601704](misc.assets/image-20240331211601704.png)

![image-20240331211614041](misc.assets/image-20240331211614041.png)

```
./steghide.exe extract -sf "D:\Users\kangye li\Desktop\1.jpg" -p  053700357621
```

解出flag.txt即可